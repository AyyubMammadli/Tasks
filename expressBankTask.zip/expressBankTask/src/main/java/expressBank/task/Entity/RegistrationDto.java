package expressBank.task.Entity;

import lombok.Data;

@Data
public class RegistrationDto {
    private String full_name;
    private String password;
    private String username;
}
